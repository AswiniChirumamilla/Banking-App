package net.javaguides.debanking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DebankingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DebankingAppApplication.class, args);
	}

}
