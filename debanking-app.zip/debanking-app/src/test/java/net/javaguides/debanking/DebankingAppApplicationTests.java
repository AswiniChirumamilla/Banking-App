package net.javaguides.debanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebankingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
